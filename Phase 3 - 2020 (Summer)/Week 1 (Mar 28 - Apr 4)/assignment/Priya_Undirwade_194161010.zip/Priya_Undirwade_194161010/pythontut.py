import numpy as np
import csv
import matplotlib.pyplot as plt
from numpy import genfromtxt
from matplotlib.pyplot import figure
from statistics import mean
# Importing the data
my_data = np.genfromtxt("data.csv",delimiter=',')
# Taking out column values

for i in range(1,11):
    x=my_data[:,i] # x stores first feature at a time
    for j in range(i+1,11):
        y=my_data[:,j] # y stores second feature at a time
        for k in range(0,len(my_data)):
           z=my_data[k,0] # z stores the label values
           if z==1:
               a=plt.plot(x[k],y[k],marker="x",color="red") #plotting label 1 with red color
           if z==2:
               b=plt.plot(x[k],y[k],marker="o",color="blue") # plotting label 2 with blue color      
        plt.title('Pair wise plotting of one feature against other',fontsize='18')
        plt.xlabel(str(i)+'(feature)',fontsize='14')
        plt.ylabel(str(j)+'(feature)',fontsize='14')
        plt.legend([b,a],labels=["2","1"],loc='upper right',title='Labels')
        # Final plot
        plt.show()
